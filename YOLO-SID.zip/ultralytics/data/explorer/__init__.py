# Ultralytics YOLO 🚀, AGPL-3.0 license

from .utils import plot_query_result

__all__ = ["plot_query_result"]
